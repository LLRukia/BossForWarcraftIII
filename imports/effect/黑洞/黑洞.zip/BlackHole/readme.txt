Black Hole

Description:
Made for a request and based on the Eye of Sargeras model. Though the only thing left of that is the ribbons.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Onyx.blp
doodads\Cinematic\EyeOfSargeras\Demon_Rune2.blp
doodads\Cinematic\EyeOfSargeras\Demon_Rune3.blp
doodads\Cinematic\EyeOfSargeras\Demon_Rune1.blp
doodads\Cinematic\EyeOfSargeras\Demon_Rune4.blp
doodads\Cinematic\EyeOfSargeras\Demon_Rune_Cracks.blp
Textures\Green_Glow2.blp
doodads\Cinematic\EyeOfSargeras\Demon_Rune_Ribbon.blp
Textures\star1.blp
Textures\RibbonNE1_White.blp
Textures\LavaLump2.blp
Textures\Green_Glow3.blp
Textures\ShockwaveWater1.blp
Textures\Blue_Glow2.blp
Textures\GenericGlowX_Mod2.blp
Textures\Clouds8x8.blp
Textures\Clouds8x8Fire.blp
Textures\ShockwaveWater1Black.blp

Downloaded from http://www.hiveworkshop.com