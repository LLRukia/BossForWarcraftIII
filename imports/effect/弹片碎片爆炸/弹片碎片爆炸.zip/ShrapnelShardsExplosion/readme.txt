Shrapnel Shards Explosion

Description:
A huge blast of large shards, which then explode in lots of tiny shrapnel.

Can be used with Shrapnel Shards missile for a Fan of Knives spell.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Clouds8x8.blp
Textures\GenericGlow64.blp
Textures\Shockwave10.blp
Textures\Clouds8x8Fire.blp
Textures\Flare.blp

Downloaded from http://www.hiveworkshop.com