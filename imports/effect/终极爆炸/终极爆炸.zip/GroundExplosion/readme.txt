GroundExplosion

Description:
For all your explosive needs.

Mostly inspired by Halo 3 explosions.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Clouds8x8Fire.blp
Textures\Clouds8x8.blp
Textures\GenericGlow64.blp
Textures\Shockwave10.blp
Textures\Shockwave1White.blp
Textures\Star7b.blp
Textures\White_64_Foam1.blp
Textures\Flare.blp
Textures\Flame4.blp

Downloaded from http://www.hiveworkshop.com