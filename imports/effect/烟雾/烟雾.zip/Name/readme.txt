Smoke granade impact
By HappyTauren

Description:
for cs:de_aztec. It draws, and then dissapears. simple.

Textures:
Textures\Clouds8x8Black.blp
Textures\Clouds8x8Grey.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2007, June 11
Model was last updated 2007, June 11


Visit http://www.hiveworkshop.com for more downloads