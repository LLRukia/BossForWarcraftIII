Blue Fireworks

Description:
Fireworks, what else?

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Flare.blp
Textures\White_64_Foam1.blp
Textures\Dust3x.blp

Downloaded from http://www.hiveworkshop.com