FrostArmorTarget

Description:
This is a time rune model. It is originally from a frost armor model. 

Pls give credits if you're using this in your map.

This model is good for time stopping in an area (like a chronosphere) or a unit.

Enjoy!!

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Ghost2.blp
Textures\Shockwave10.blp
24h_clock_v1.blp

Downloaded from http://www.hiveworkshop.com