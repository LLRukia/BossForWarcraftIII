Mist Aura
By Pyritie

Description:
Made for War of the Ancients. Give credits if you use it.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, April 12


Visit http://www.hiveworkshop.com for more downloads