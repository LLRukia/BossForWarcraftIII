Frost Warp
By Pyritie

Description:
Made for The Hive Workshop's SFX Competition #1.

Give credits to Pyritie if you use it.

[img]http://www.deviantart.com/download/75991548/Frost_Warp_by_Pyritie.gif[/img]

Note: The squares in the above .gif have been fixed. They are much less visible in the actual model.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 1969, December 31
Model was last updated 2008, February 2


Visit http://www.hiveworkshop.com for more downloads