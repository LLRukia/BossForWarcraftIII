InfernalBirth

Description:
For my Crystal Infernal Model.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\CrystalOpaque.blp
Textures\Yellow_Glow3.blp
Textures\star32.blp
ReplaceableTextures\Weather\Clouds8x8.blp
Textures\Clouds8x8Grey.blp
Textures\clouds_anim1_bw.blp
Textures\Dust3.blp
Textures\Dust5A.blp
Textures\rock64.blp
Textures\Shockwave10.blp
Textures\grad2b.blp

Downloaded from http://www.hiveworkshop.com