Shiva's Enchantment
By Shiva's Enchantment

Description:
Don't be offended by the name because it's only refrencing the summon from Final Fantasy. Made for the SFX Competition. Give credits if you use.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 1969, December 31
Model was last updated 2008, February 4


Visit http://www.hiveworkshop.com for more downloads