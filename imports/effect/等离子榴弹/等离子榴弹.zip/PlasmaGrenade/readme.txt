Plasma Grenade

Description:
A grenade model based on Halo 3's ultra-awesome sticky Plasma Grenade.

Yes, it has a stand animation (for missiles), and yes it requires a custom texture.

Skins:
(the skins listed below are not nescessarily in this zip package, they are just a list of the skins used by the model.)Textures\Clouds8x8Fade.blp
Doodads\Cinematic\EyeOfSargeras\Demon_Rune_Cracks.blp
Textures\Clouds8x8Fire.blp
Textures\GenericGlow64.blp
Textures\White_64_Foam1.blp
Textures\Blue_Glow2.blp
LightningRingFINAL.blp

Downloaded from http://www.hiveworkshop.com