Laser Strike
By WILLTHEALMIGHTY

Description:
Do not modify without permission.

Also, watch out for overusing the effect, it might cause lag.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 1969, December 31
Model was last updated 2008, January 20


Visit http://www.hiveworkshop.com for more downloads